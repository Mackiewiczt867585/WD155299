def urojona (x,y):
    print(y,'i')

def rzeczywista (x,y):
    print(x)
